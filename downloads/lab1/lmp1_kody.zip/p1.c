#include <stdio.h>

int main(void)
{
    printf("Dzien dobry!");
    return 0;
}
