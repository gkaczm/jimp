#include <stdio.h>

int main(void)
{
    int i;

    printf("Kody dziesietne wielkich liter:\n");
    for (i = 'A'; i <= 'Z'; i++)
        printf("%c - %d\n", i, i);

    return 0;
}
