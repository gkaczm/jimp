#ifndef BIBL_H
#define BIBL_H

/* compare() odczytuje stąd T oraz oryginalne pomiary. */
extern double T;
extern const double *pomiary;

int compare(const void *a, const void *b);
void insort(int tab[], int n);
int identyczne(const int a[], const int b[], int n);
int zapisz_wynik(const char *nazwa, const int tab[], int k);

#endif
