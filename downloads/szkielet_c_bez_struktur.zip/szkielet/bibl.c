#include "bibl.h"
#include <math.h>
#include <stdio.h>

double T = 0.0;
const double *pomiary = NULL;

int compare(const void *a, const void *b)
{
    /* Elementami sortowanej tablicy są indeksy typu int. */
    int ia = *(const int *)a;
    int ib = *(const int *)b;

    /* TODO 4: porównaj kolejno:
       - fabs(pomiary[ia] - T) oraz fabs(pomiary[ib] - T),
       - wartości pomiary[ia] oraz pomiary[ib],
       - indeksy ia oraz ib.
       Zwróć liczbę ujemną, zero lub dodatnią.
       Nie zamieniaj różnicy odległości na int. */

    (void)ia;
    (void)ib;
    return 0; /* Wynik tymczasowy: zastąp go właściwym porównaniem. */
}

void insort(int tab[], int n)
{
    /* TODO 6: zaimplementuj sortowanie przez wstawianie.
       Przesuwaj indeksy w tab[], nie pomiary w oryginale.
       Do porównania możesz użyć compare(&tab[j], &tmp).
       Sprawdź j >= 0 przed odczytem tab[j]. */

    (void)tab;
    (void)n;
}

int identyczne(const int a[], const int b[], int n)
{
    /* TODO 7: sprawdź wszystkie pozycje obu tablic indeksów.
       Zwróć 1, jeśli są identyczne, albo 0 w przeciwnym przypadku. */

    (void)a;
    (void)b;
    (void)n;
    return 0; /* Wynik tymczasowy. */
}

int zapisz_wynik(const char *nazwa, const int tab[], int k)
{
    /* TODO 9: otwórz plik nazwa w trybie "w" i sprawdź wynik.
       Zapisz nagłówek: indeks wartosc odleglosc
       Dla j od 0 do k-1 zapisz:
       tab[j], pomiary[tab[j]], fabs(pomiary[tab[j]] - T).
       Zamknij plik. Zwróć 1 po sukcesie lub 0 po błędzie.
       Pamiętaj: tab[j] jest indeksem, nie wartością pomiaru. */

    (void)nazwa;
    (void)tab;
    (void)k;
    return 0; /* Wynik tymczasowy. */
}
