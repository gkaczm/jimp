# Ćwiczenie dodatkowe 1 — pliki startowe

Sortujemy dwie tablice indeksów typu `int`. Tablica `dane` zawierająca pomiary typu `double` pozostaje niezmieniona. Wartość pomiaru na pozycji `j` wyniku odczytujemy jako `dane[indeksy_q[j]]`.

## Co jest przygotowane?

- Podział na `main.c`, `bibl.c` i `bibl.h`, nagłówki i deklaracje funkcji.
- Wczytywanie i sprawdzanie danych, przydzielenie oraz zwolnienie pamięci.
- Definicje `T` i wskaźnika `pomiary`, z którego korzysta funkcja porównująca.
- Wywołania funkcji pomocniczych i komunikaty programu.

## Co uzupełnić?

| Numer TODO | Plik | Zadanie |
| --- | --- | --- |
| 1 | main.c | Przygotowanie indeksów 0, 1, ..., n-1 |
| 2 | main.c | Kopiowanie tablicy indeksów pętlą |
| 3 | main.c | Ręczne wyznaczenie kolejności dla małego przykładu |
| 4 | bibl.c | Trzy kryteria porównania w compare() |
| 5 | main.c | Wywołanie qsort() |
| 6 | bibl.c | Własne sortowanie przez wstawianie |
| 7 | bibl.c | Porównanie wynikowych tablic indeksów |
| 8 | main.c | Średnia wybranych pomiarów |
| 9 | bibl.c | Zapis pliku wynik.txt |

Instrukcje takie jak `(void)tab;` tymczasowo wyciszają ostrzeżenia o nieużywanych parametrach. Usuń je, gdy wykorzystasz te parametry w swoim kodzie. Tymczasowe instrukcje `return 0;` zastąp wynikiem właściwej implementacji.

Szkielet można od razu skompilować. Początkowo wypisuje komunikat o konieczności uzupełnienia i kończy się kodem błędu. **Po uzupełnieniu wszystkich TODO ustaw `gotowe = 1` na początku main().** Sama zmiana tej wartości nie wystarczy do rozwiązania zadania.

## Kompilacja i uruchomienie

W katalogu plików startowych wykonaj:

```bash
gcc -std=c11 -Wall -Wextra -Wpedantic -g main.c bibl.c -lm -o pomiary
./pomiary < dane.txt
```

Po ukończeniu programu dla dołączonego wejścia obie tablice indeksów powinny zawierać `2, 6, 1, 5, 0, 4, 3`. Średnia pierwszych czterech wskazywanych wartości wynosi `1.5`.

Plik `wynik.txt` powinien zawierać:

```text
indeks wartosc odleglosc
2 2 0
6 2 0
1 1 1
5 1 1
```

Możesz zapisać wartości z większą liczbą cyfr po kropce. Sprawdź również pozostałe przypadki opisane w treści ćwiczenia.

## Co oznacza extern w bibl.h?

`extern double T;` i `extern const double *pomiary;` są deklaracjami: podają nazwy i typy zmiennych wspólnych dla obu plików `.c`. Bez inicjalizatorów nie tworzą kolejnych zmiennych ani ich kopii. Definicje `double T = 0.0;` i `const double *pomiary = NULL;` znajdują się tylko raz, w `bibl.c`.

Dzięki dołączeniu `bibl.h` funkcja `main()` może ustawić `T` oraz wykonać `pomiary = dane;`, a `compare()` odczytuje te same zmienne. Sam wskaźnik nie przydziela pamięci na pomiary — robi to osobne wywołanie `malloc()`.

Nie przenoś definicji zmiennych do nagłówka dołączanego do obu plików. `extern` jest tu potrzebne do udostępnienia deklaracji pomiędzy plikami; nie jest obowiązkowym dodatkiem do każdej zmiennej globalnej.

Globalny kontekst wynika z przyjętego sposobu użycia `qsort()`: funkcja porównująca otrzymuje tylko dwa adresy indeksów, bez dodatkowego parametru z tablicą pomiarów i wartością `T`.
