#include "bibl.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    /* Po uzupełnieniu wszystkich TODO zmień 0 na 1.
       Do tego czasu program kompiluje się, ale nie przetwarza danych. */
    const int gotowe = 0;
    if (!gotowe) {
        fprintf(stderr, "Uzupelnij TODO 1-9 i ustaw gotowe = 1.\n");
        return EXIT_FAILURE;
    }

    int n, k;
    if (scanf("%d %lf %d", &n, &T, &k) != 3 ||
        n < 1 || n > 100 || k < 1 || k > n || !isfinite(T)) {
        fprintf(stderr, "Niepoprawne n, T lub k.\n");
        return EXIT_FAILURE;
    }

    double *dane = malloc((size_t)n * sizeof *dane);
    int *indeksy_q = malloc((size_t)n * sizeof *indeksy_q);
    int *indeksy_i = malloc((size_t)n * sizeof *indeksy_i);
    int status = EXIT_FAILURE;

    if (dane == NULL || indeksy_q == NULL || indeksy_i == NULL) {
        fprintf(stderr, "Brak pamieci.\n");
    } else {
        int poprawne = 1;
        for (int i = 0; i < n; ++i) {
            if (scanf("%lf", &dane[i]) != 1 || !isfinite(dane[i]) ||
                !isfinite(dane[i] - T)) {
                fprintf(stderr, "Niepoprawny pomiar (indeks %d).\n", i);
                poprawne = 0;
                break;
            }
        }

        if (poprawne) {
            /* TODO 1: wypełnij indeksy_q liczbami 0, 1, ..., n-1. */

            /* TODO 2: skopiuj elementy indeksy_q do indeksy_i.
               Użyj pętli. Nie przypisuj jednego wskaźnika do drugiego. */

            /* TODO 3: w tym miejscu prześledź na kartce mały przykład:
               dane = [3, 1, 2], T = 2.
               Jaka powinna być kolejność indeksów po sortowaniu?
               Zapisz odpowiedź w komentarzu. */

            /* Udostępniamy oryginał funkcji compare(). */
            pomiary = dane;

            /* TODO 5: wywołaj qsort() dla indeksy_q.
               Elementami tej tablicy są liczby typu int. */

            insort(indeksy_i, n);

            int zgodne = identyczne(indeksy_q, indeksy_i, n);
            printf("Kolejnosci identyczne: %s\n", zgodne ? "TAK" : "NIE");

            if (zgodne) {
                double srednia = 0.0;
                /* TODO 8: oblicz średnią wartości wskazywanych przez
                   pierwszych k elementów indeksy_q.
                   Przyjmij niewielkie wartości, jak w przykładach zadania. */
                printf("Srednia wybranych pomiarow: %.10g\n", srednia);

                if (zapisz_wynik("wynik.txt", indeksy_q, k)) {
                    printf("Zapisano %d pomiarow do wynik.txt\n", k);
                    status = EXIT_SUCCESS;
                } else {
                    fprintf(stderr, "Nie udalo sie zapisac wynik.txt.\n");
                }
            }
        }
    }

    free(indeksy_i);
    free(indeksy_q);
    pomiary = NULL;
    free(dane);
    return status;
}
