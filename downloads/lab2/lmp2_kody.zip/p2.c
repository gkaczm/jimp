#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* Makro LL podajemy podczas kompilacji, np. -DLL=5. */
int main(int argc, char *argv[])
{
    int n = argc > 1 ? atoi(argv[1]) : 10;
    double min = argc > 2 ? atof(argv[2]) : 0.0;
    double max = argc > 3 ? atof(argv[3]) : 1.0;
    FILE *out = argc > 4 ? fopen(argv[4], "w") : stdout;
    int i;

    if (out == NULL) {
        fprintf(stderr, "%s: nie moge pisac do %s\n", argv[0], argv[4]);
        return 1;
    }

    srand((unsigned)time(NULL));
    for (i = 0; i < n; i++) {
        double ulamek = (double)rand() / RAND_MAX;
        fprintf(out, "%g%c", min + (max - min) * ulamek,
                i % LL == LL - 1 ? '\n' : ' ');
    }
    if (i % LL != 0)
        fprintf(out, "\n");

    if (out != stdout)
        fclose(out);
    return 0;
}
