#include <stdio.h>
#include <stdlib.h>

double sum(double v[], int n)
{
    double s = v[0];
    while (--n)
        s += v[n];
    return s;
}

void pwekt(double v[], int n)
{
    int i;
    printf("[");
    for (i = 0; i < n; i++)
        printf(" %g", v[i]);
    printf(" ]");
}

int main(int argc, char *argv[])
{
    double r[1000];
    int i;
    int l = argc - 1;

    /* Bez argumentow funkcja sum() odczytalaby niezainicjowane r[0]. */
    if (l == 0 || l > 1000) {
        fprintf(stderr, "Podaj od 1 do 1000 liczb.\n");
        return 1;
    }

    for (i = 1; i < argc; i++)
        r[i - 1] = atof(argv[i]);

    pwekt(r, l);
    printf(", suma elementow = %g\n", sum(r, l));
    printf("wektor ma %d elementow\n", l);
    return 0;
}
