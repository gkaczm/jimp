LMP/5 — pliki startowe do laboratorium „Uruchamianie programów”.

ZAWARTOSC:
  insort.c / insort.h — sortowanie przez wstawianie (celowe bledy)
  q_sort.c / q_sort.h — sortowanie szybkie (celowe bledy)
  test.c            — program testujacy Insertion Sort

Uwaga: To odtworzony zestaw na podstawie oryginalnego materialu LMP/5,
a nie archiwalny plik lmp5.tgz. W test.c dodano sprawdzanie argumentu,
zwalnianie pamieci i komunikat "Kontrola: OK"; wzor losowania zapisano
bez ryzyka przepelnienia przy mnozeniu int. Bledy w algorytmach pozostawiono.

POLECENIE KOMPILACJI:
  gcc -Wall -g -DMAX_ELEM_2_PRINT=12 insort.c test.c -o insort_test

Quick Sort: skopiuj test.c do qtest.c, zamien naglowek insort.h
na q_sort.h i wywolanie insort(v,n) na q_sort(v,n). Nastepnie:
  gcc -Wall -g -DMAX_ELEM_2_PRINT=12 q_sort.c qtest.c -o quick_test

Nie oczekuj poprawnej kompilacji/dzialania bez naprawienia bledow.
